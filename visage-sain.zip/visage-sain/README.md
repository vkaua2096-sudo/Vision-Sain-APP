# Visage Sain - Como subir no Vercel

## Passos:

### 1. Acesse vercel.com e clique em "Add New Project"

### 2. Escolha "Deploy" sem conectar GitHub
- Procure a opção "Deploy without Git"
- Ou arraste a pasta `visage-sain` inteira pra área de upload

### 3. Configure variável de ambiente (IMPORTANTE!)
- Antes de fazer deploy, vá em "Environment Variables"
- Adicione:
  - **Name**: `ANTHROPIC_API_KEY`
  - **Value**: cole sua API Key (sk-ant-...)
- Clica em "Add"

### 4. Clica em "Deploy"

### 5. Pronto! Em ~30 segundos terá uma URL tipo:
- `visage-sain-xxx.vercel.app`

## Como testar:
1. Abre a URL no celular
2. Tira uma foto ou faz upload
3. Aguarda o diagnóstico
4. Clica em "Falar no WhatsApp"
